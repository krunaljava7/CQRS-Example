package exploringaxon.eventhandler;

import javax.jms.Queue;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsMessagingTemplate;
import org.springframework.stereotype.Component;

@Component
public class Producer {

	@Autowired
	private JmsMessagingTemplate jmsMessagingTemplate;

	@Autowired()
	@Qualifier("creditQueue")
	private Queue creditQueue;
	
	@Autowired()
	@Qualifier("debitQueue")
	private Queue debitQueue;

	public void sendCreditMessage(String msg) {
		this.jmsMessagingTemplate.convertAndSend(this.creditQueue, msg);
	}
	
	public void sendDebitMessage(String msg) {
		this.jmsMessagingTemplate.convertAndSend(this.debitQueue, msg);
	}
}
