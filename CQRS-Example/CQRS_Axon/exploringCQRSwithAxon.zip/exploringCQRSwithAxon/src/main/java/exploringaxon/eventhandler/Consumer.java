package exploringaxon.eventhandler;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class Consumer {

	@Autowired
    DataSource dataSource;
	
	@JmsListener(destination = "credit.queue")
	public void receiveCreditQueue(String text){
		
		System.out.println(text);
		String arr[] = text.split("-->");
		
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

        // Get the current states as reflected in the event
        String accountNo = arr[0];
        Double balance = Double.parseDouble(arr[1]);
        Double amountCredited = Double.parseDouble(arr[2]);
        Double newBalance = balance + amountCredited;

        // Update the view
        String updateQuery = "UPDATE account_view SET balance = ? WHERE account_no = ?";
        jdbcTemplate.update(updateQuery, new Object[]{newBalance, accountNo});

        System.out.println("Events Handled With EventMessage " + arr[3] + " at " + arr[4]);
	}
	
	@JmsListener(destination = "debit.queue")
	public void receiveDebitQueue(String text){
		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

		System.out.println(text);
		String arr[] = text.split("-->");
        // Get the current states as reflected in the event
        String accountNo = arr[0];
        Double balance = Double.parseDouble(arr[1]);
        Double amountDebited = Double.parseDouble(arr[2]);
        Double newBalance = balance - amountDebited;

        // Update the view
        String updateQuery = "UPDATE account_view SET balance = ? WHERE account_no = ?";
        jdbcTemplate.update(updateQuery, new Object[]{newBalance, accountNo});
	}
}
